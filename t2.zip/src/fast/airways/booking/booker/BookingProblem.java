package fast.airways.booking.booker;

/**
 * Created by IntelliJ IDEA.
 * User: Bradley.Hart
 * Date: 17-Jul-2010
 * Time: 18:30:03
 * To change this template use File | Settings | File Templates.
 */
public enum BookingProblem {
    INVALID_CUSTOMER,
    INVALID_FLIGHT,
    BOOKING_NOT_SAVED
}
