package fast.airways.booking;

/**
 * Created by IntelliJ IDEA.
 * User: Bradley.Hart
 * Date: 17-Jul-2010
 * Time: 18:34:07
 * To change this template use File | Settings | File Templates.
 */
public class BookingNotMadeException extends Exception {
}
