package fast.airways.customer;

/**
 * Created by IntelliJ IDEA.
 * User: Bradley.Hart
 * Date: 17-Jul-2010
 * Time: 18:27:51
 * To change this template use File | Settings | File Templates.
 */
public class CustomerNotFoundException extends Exception {
    
}
