package fast.airways.customer;

/**
 * Created by IntelliJ IDEA.
 * User: Bradley.Hart
 * Date: 17-Jul-2010
 * Time: 18:23:22
 * To change this template use File | Settings | File Templates.
 */
public class Customer {
    // doesnt matter
    

}
