package fast.airways.flight;

/**
 * Created by IntelliJ IDEA.
 * User: Bradley.Hart
 * Date: 17-Jul-2010
 * Time: 18:28:28
 * To change this template use File | Settings | File Templates.
 */
public class FlightNotFoundException extends Exception {
}
