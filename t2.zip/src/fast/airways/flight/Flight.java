package fast.airways.flight;

/**
 * Created by IntelliJ IDEA.
 * User: Bradley.Hart
 * Date: 17-Jul-2010
 * Time: 17:59:06
 * To change this template use File | Settings | File Templates.
 */
public class Flight {
    // doesnt matter
}
